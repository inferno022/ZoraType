If you're poking around here, please know that this system is not necessarily finalized and anything you make is not guaranteed to work in future versions.

This theme is intended for FUTO Keyboard v0.1.27.x
