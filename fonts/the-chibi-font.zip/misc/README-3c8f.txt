***PERSONAL USE - NON COMMERCIAL***
Get Commercial use in:
https://ljdesignstudios.com/the-chibi-font/
or contact: fonts@ljdesignstudios.com

Follow me for more fonts:
Instagram
https://instagram.com/ljds.co

Facebook
https://www.facebook.com/LJDS.COL

Twitter
https://twitter.com/ljdesigne

Behance
https://www.behance.net/LJDS