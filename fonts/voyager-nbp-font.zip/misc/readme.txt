VOYAGER NBP
made by Nate Halley
using FontStruct
Version 1.0
Date: 13 May 2013

DESCRIPTION
===========
A sci-fi design inspired by the Google Android logo and Aldo Novarese's 1971 design, Stop.

LICENSE
=======
Voyager and all related images are Creative Commons (by-sa) Attribution Share Alike. That means it's free to download and use. You can also upload it to another website but only as long as you give me credit for making it. You can even make changes to it as long as you give me credit for making the first version and license your new version as CC-BY-SA too.
For more information, go to:
http://creativecommons.org/licenses/by-sa/3.0/

A REQUEST FROM NATE547
======================
Once you install this font, find 2 ways to make the world, the country, your home state/province/county, or your hometown better than it is. Even if it's just recycling your newspaper instead of tossing it on the rubbish.
Of course, you're not obligated by law to do this.... it's just a request from a Sensible Human who wants our world to change.

Duty now for the future.

Nate547 (Total FontGeek)